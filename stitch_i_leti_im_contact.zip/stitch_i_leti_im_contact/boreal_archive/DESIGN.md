# Design System Strategy: The Institutional Editorial

## 1. Overview & Creative North Star
**Creative North Star: "The Bilingual Curator"**

This design system is engineered to feel like a high-end, contemporary museum catalog or a premium academic journal. It rejects the "app-like" fatigue of rounded corners and heavy shadows in favor of **Institutional Editorialism**. 

The system moves beyond the standard grid by embracing **intentional asymmetry and linguistic hierarchy**. By treating bilingual text as a visual texture rather than a functional chore, we create a rhythmic, high-contrast experience that feels both authoritative and avant-garde. We break the "template" look through massive typography scales, generous white space, and a strict refusal of structural lines.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a crisp `surface` (#fcf9f8), using the primary `Deep Blue/Purple` (#4530e0) to anchor the eye and `Vibrant Orange` (#f7a823) to punctuate critical actions.

### The "No-Line" Rule
Traditional 1px borders are strictly prohibited for sectioning. Definition must be achieved through:
- **Tonal Shifts:** Transitioning from `surface` to `surface-container-low` to define content blocks.
- **Negative Space:** Using the `12` (4rem) or `16` (5.5rem) spacing tokens to create "invisible" boundaries.

### Surface Hierarchy & Nesting
Treat the UI as a series of stacked fine papers.
- **Base Layer:** `surface` (#fcf9f8) for the main page.
- **Content Blocks:** `surface-container-low` (#f6f3f2) for large sectioning.
- **Interactive Elements:** `surface-container-lowest` (#ffffff) for cards or inputs to create a "lifted" feel without shadows.

### The "Glass & Gradient" Rule
To add soul to the institutional look:
- **Signature CTA Gradient:** Use a linear gradient from `primary` (#2c00c5) to `primary_container` (#4530e0) at a 135-degree angle.
- **Glassmorphism:** Navigation bars and floating modals should use `surface` with 80% opacity and a `20px` backdrop-blur to maintain the "editorial" transparency.

---

## 3. Typography: Linguistic Rhythm
We use **Manrope** exclusively. The hallmark of this system is the **Bilingual Pattern**, which must be applied to every piece of copy.

*   **Turkish (Primary):** Regular or Bold weight, `on_surface` color.
*   **English (Secondary):** One size smaller than the Turkish counterpart, *Italic*, `on_surface_variant` color, placed directly beneath with a `1` (0.35rem) gap.

### Typography Scale
- **Display-LG (3.5rem):** Reserved for hero titles. Tracking: -0.02em.
- **Headline-MD (1.75rem):** For major section starts.
- **Body-LG (1rem):** Primary reading weight. Line-height: 1.6 for maximum readability.
- **Label-SM (0.6875rem):** Used for the English sub-text under labels.

---

## 4. Elevation & Depth
Depth in this system is "Tonal," not "Structural."

*   **The Layering Principle:** To highlight a card, place a `surface-container-lowest` (#ffffff) card on top of a `surface-container-low` (#f6f3f2) background. This creates a clean, sophisticated edge.
*   **Ambient Shadows:** If an element must float (e.g., a dropdown), use a shadow: `0px 20px 40px rgba(28, 27, 27, 0.06)`. The tint is derived from `on_surface` to keep it natural.
*   **The "Ghost Border":** For high-accessibility needs, use `outline_variant` at 15% opacity. Never use 100% opaque borders.

---

## 5. Components

### Buttons: The "Curator" Variants
- **Primary:** Gradient fill (`primary` to `primary_container`), white text. `lg` (0.5rem) corner radius.
- **Secondary:** `surface_container_high` background with `primary` text. No border.
- **Tertiary:** Text-only, using the Bilingual Pattern (Turkish/English) even within the button label.

### Inputs & Fields
- **Container:** `surface_container_low` background with a bottom-only "Ghost Border" of 2px using `primary` when focused.
- **Bilingual Labels:** The label above the field must follow the standard Turkish/English italic stack.

### Editorial Cards
- **Construction:** No borders. No shadows. 
- **Differentiation:** Use a slight background shift to `surface_container_highest` on hover. 
- **Spacing:** Enforce `spacing-5` (1.7rem) internal padding to ensure the "Modern Institutional" breathability.

### The "Bilingual List"
- Forbid divider lines. Use `spacing-4` (1.4rem) between list items.
- Leading elements (icons/numbers) should use the `secondary` (#f7a823) color to act as a high-contrast guide for the eye.

---

## 6. Do's and Don'ts

### Do:
- **Do** lean into extreme white space. If it feels like "too much" space, add 20% more.
- **Do** ensure the English italic sub-text is always legible (minimum 11px).
- **Do** use the `secondary` orange sparingly—only for "Look Here" moments or critical status updates.

### Don't:
- **Don't** use 1px solid black borders. It destroys the "Editorial" feel and makes the UI look like a legacy form.
- **Don't** use standard "drop shadows" with default settings.
- **Don't** center-align long-form bilingual text. Keep it flush-left to maintain the "institutional" vertical axis.
- **Don't** mix Manrope with other typefaces. Its strength lies in its geometric consistency.